// main.js (FIXED: never-silent render + stable matching + hover sound)
// If anything goes wrong, it will render the error text onto the canvas.

const CONFIG = {
  maxMinute: 40,
  pad: 18,
  sidebarW: 260,
  bottomH: 130,
  baseR0: 7.0,
  baseRk: 2.6,
  laneSlots: 4,
  EMO: {
    1: { a: "#E6002E", b: "#00B85C" },
    2: { a: "#FF6A00", b: "#005CFF" },
    3: { a: "#FFD000", b: "#5A00FF" },
    4: { a: "#00A8D6", b: "#D100B8" },
    5: { a: "#1B007A", b: "#FF0048" },
  },
  CAUSE_TINT: {
    Gank: "#ff2b5c",
    Vision: "#00d1ff",
    Objective: "#ffd400",
    Teamfight: "#7b2cff",
    Overextend: "#ff7a18",
    Solo: "#2d7bff",
    Towerdive: "#35e39b",
    Misplay: "#ff3b2a",
    Unknown: "#6c7a89",
  },
  AREA_ANGLE: {
    Top: -0.9, Jungle: -0.5, Mid: 0.0, Bot: 0.7, River: 1.1, Dragon: 1.35, Baron: -1.2, Base: 2.4, Unknown: 0.4,
  },
  smearByPhase(phase) {
    if (phase === "Late") return 1.0;
    if (phase === "Mid") return 0.7;
    return 0.45;
  },
  isVisionYes(v) {
    return String(v || "").toLowerCase() === "yes";
  }
};

// ---------- utils ----------
async function loadCSV(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load CSV: ${path} (${res.status})`);
  const text = await res.text();
  const lines = text.trim().split("\n");
  const headers = lines[0].split(",").map(h => h.trim());
  return lines.slice(1).map(line => {
    const cols = line.split(",").map(c => c.trim());
    return Object.fromEntries(headers.map((h, i) => [h, cols[i]]));
  });
}

const num = (x, fb = 0) => (Number.isFinite(Number(x)) ? Number(x) : fb);
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function countBy(rows, key) {
  const m = new Map();
  for (const r of rows) {
    const k = r[key] || "Unknown";
    m.set(k, (m.get(k) || 0) + 1);
  }
  return [...m.entries()].sort((a, b) => b[1] - a[1]);
}

function hexToRgb(hex) {
  const h = hex.replace("#", "");
  return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
}
function rgba(hex, a) {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
function hash01(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

function radialDye(ctx, cx, cy, r0, r1, cA, cB, alpha) {
  const g = ctx.createRadialGradient(cx, cy, r0, cx, cy, r1);
  g.addColorStop(0.0, rgba(cB, alpha));
  g.addColorStop(0.45, rgba(cA, alpha * 0.65));
  g.addColorStop(1.0, rgba(cA, 0.0));
  return g;
}
function dyeGradient(ctx, x0, y0, x1, y1, c1, c2, a1, a2) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0.0, rgba(c1, a1));
  g.addColorStop(1.0, rgba(c2, a2));
  return g;
}

// ---------- SOUND ----------
const SFX = (() => {
  let ctx = null, master = null;
  let lastId = null, lastT = 0;

  const ensure = () => {
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = 0.22;
    master.connect(ctx.destination);
  };

  const phaseToRelease = (p) => p === "Late" ? 0.70 : (p === "Mid" ? 0.45 : 0.25);
  const causeToWave = (c) => ({
    Gank: "sawtooth", Teamfight: "square", Objective: "triangle", Vision: "sine",
    Misplay: "triangle", Overextend: "sawtooth", Towerdive: "square", Solo: "sine",
  }[c] || "triangle");
  const areaToPan = (a) => ({
    Top: -0.6, Jungle: -0.3, Mid: 0.0, River: 0.2, Bot: 0.6, Dragon: 0.4, Baron: -0.4, Base: 0.1
  }[a] ?? 0.0);
  const emotionToGain = (e) => 0.05 + (e - 1) * 0.042;
  const minuteToFreq = (m) => {
    m = Math.max(0, Math.min(40, m));
    const f0 = 130.81, f1 = 1046.5;
    const t = m / 40;
    return f0 * Math.pow(f1 / f0, t);
  };

  const play = (evt) => {
    ensure();
    const now = ctx.currentTime;
    if (evt._id === lastId && (now - lastT) < 0.12) return;
    lastId = evt._id; lastT = now;

    const emotion = clamp(Math.round(Number(evt.emotion || 3)), 1, 5);
    const minute = Number(evt.minute || 0);
    const release = phaseToRelease(evt.phase);
    const freq = minuteToFreq(minute);

    const osc = ctx.createOscillator();
    osc.type = causeToWave(evt.cause);
    osc.frequency.setValueAtTime(freq, now);

    const gain = ctx.createGain();
    const peak = emotionToGain(emotion);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(peak, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + release);

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(800 + emotion * 900, now);

    const panner = ctx.createStereoPanner();
    panner.pan.setValueAtTime(areaToPan(evt.area), now);

    if (String(evt.vision || "").toLowerCase() === "yes") {
      const ping = ctx.createOscillator();
      ping.type = "sine";
      ping.frequency.setValueAtTime(freq * 2.2, now);
      const pg = ctx.createGain();
      pg.gain.setValueAtTime(0.0001, now);
      pg.gain.exponentialRampToValueAtTime(peak * 0.6, now + 0.005);
      pg.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      ping.connect(pg).connect(master);
      ping.start(now); ping.stop(now + 0.14);
    }

    osc.connect(filter).connect(gain).connect(panner).connect(master);
    osc.start(now); osc.stop(now + release + 0.02);
  };

  const unlock = async () => {
    ensure();
    if (ctx?.state === "suspended") await ctx.resume();
  };

  return { play, unlock };
})();

// ---------- UI helpers ----------
function hideExtraCharts() {
  for (const id of ["causeChart", "timeChart", "areaChart"]) {
    const el = document.getElementById(id);
    if (!el) continue;
    const card = el.closest(".card");
    if (card) card.style.display = "none";
    else el.style.display = "none";
  }
}

function bindHoverSound(canvas) {
  if (canvas._hoverBound) return;
  canvas._hoverBound = true;

  canvas.addEventListener("mousemove", (ev) => {
    const pts = canvas._hitPoints || [];
    if (!pts.length) return;

    const b = canvas.getBoundingClientRect();
    const mx = ev.clientX - b.left;
    const my = ev.clientY - b.top;

    let best = null, bestD2 = Infinity;
    for (const p of pts) {
      const dx = mx - p.x, dy = my - p.y;
      const d2 = dx * dx + dy * dy;
      if (d2 < p.r * p.r && d2 < bestD2) { bestD2 = d2; best = p; }
    }
    if (best) SFX.play(best.evt);
  });

  const unlock = () => SFX.unlock();
  canvas.addEventListener("mousedown", unlock, { passive: true });
  canvas.addEventListener("touchstart", unlock, { passive: true });
}

// ---------- render (safe) ----------
function renderDashboard(canvas, rows) {
  const ctx = canvas.getContext("2d");

  // sizing
  const rect = canvas.getBoundingClientRect();
  const cssW = Math.max(760, Math.floor(rect.width || 900));
  const cssH = Math.max(520, Math.floor(cssW * 0.62));
  const dpr = window.devicePixelRatio || 1;

  canvas.width = Math.floor(cssW * dpr);
  canvas.height = Math.floor(cssH * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  const W = cssW, H = cssH;
  const { pad, sidebarW, bottomH } = CONFIG;

  const mainX = pad, mainY = pad;
  const mainW = W - pad * 2 - sidebarW;
  const mainH = H - pad * 2 - bottomH;

  const sideX = mainX + mainW + 16, sideY = mainY;
  const sideW = sidebarW - 16, sideH = mainH;

  const botX = mainX, botY = mainY + mainH + 16;
  const botW = mainW, botH = bottomH - 16;

  // background + faint grain
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "rgba(0,0,0,0.012)";
  for (let i = 0; i < 1600; i++) ctx.fillRect((i * 37) % W, (i * 91) % H, 1, 1);

  // frames
  ctx.strokeStyle = "rgba(0,0,0,0.08)";
  ctx.lineWidth = 1;
  ctx.strokeRect(mainX, mainY, mainW, mainH);
  ctx.strokeRect(sideX, sideY, sideW, sideH);
  ctx.strokeRect(botX, botY, botW, botH);

  // subtle grid main
  ctx.strokeStyle = "rgba(0,0,0,0.03)";
  for (let i = 0; i <= 10; i++) {
    const gx = mainX + (mainW * i) / 10;
    ctx.beginPath(); ctx.moveTo(gx, mainY); ctx.lineTo(gx, mainY + mainH); ctx.stroke();
  }
  for (let i = 0; i <= 8; i++) {
    const gy = mainY + (mainH * i) / 8;
    ctx.beginPath(); ctx.moveTo(mainX, gy); ctx.lineTo(mainX + mainW, gy); ctx.stroke();
  }

  // prep rows
  const maxMin = CONFIG.maxMinute;

  // IMPORTANT FIX: normalize match as string to avoid strict equality surprises
  const matches = [...new Set(rows.map(r => String(r.match).trim()))].sort((a, b) => Number(a) - Number(b));
  const rowH = mainH / Math.max(1, matches.length);

  const hitPoints = [];

  const drawBlot = (cx, cy, baseR, emoA, emoB, causeTint, angle, smearK, visionOn, key) => {
    const jitter = hash01(key + "|j") - 0.5;
    const jx = jitter * baseR * 0.25;
    const jy = (hash01(key + "|jy") - 0.5) * baseR * 0.25;

    const dx = Math.cos(angle);
    const dy = Math.sin(angle);

    // core
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1.0;
    ctx.fillStyle = radialDye(ctx, cx + jx, cy + jy, 0, baseR * 1.15, emoA, emoB, 0.92);
    ctx.beginPath();
    ctx.arc(cx + jx, cy + jy, baseR, 0, Math.PI * 2);
    ctx.fill();

    // cause dye
    ctx.globalAlpha = 0.60;
    const shift = baseR * (0.75 + smearK * 0.6);
    const cdx = dx * shift * 0.20;
    const cdy = dy * shift * 0.20;
    ctx.fillStyle = radialDye(ctx, cx + cdx, cy + cdy, 0, baseR * 1.35, causeTint, causeTint, 0.90);
    ctx.beginPath();
    ctx.arc(cx + cdx, cy + cdy, baseR * 0.95, 0, Math.PI * 2);
    ctx.fill();

    // halo fusion
    ctx.globalCompositeOperation = "lighter";
    const haloBlur = 10 + baseR * 0.65 + smearK * 12;
    const steps = 8 + Math.round(smearK * 5);
    const drag = baseR * (2.6 + smearK * 2.6);

    for (let i = 0; i < steps; i++) {
      const t = i / (steps - 1);
      const ox = dx * (t - 0.5) * drag;
      const oy = dy * (t - 0.5) * drag;

      const a = (0.18 + smearK * 0.20) * (1.0 - t * 0.55);
      const colA = (i % 2 === 0) ? emoA : emoB;

      ctx.globalAlpha = a;
      ctx.filter = `blur(${haloBlur + t * 10}px)`;

      const hg = ctx.createRadialGradient(cx + ox, cy + oy, 0, cx + ox, cy + oy, baseR * (2.4 + t * 1.2));
      hg.addColorStop(0.0, rgba(colA, 0.55));
      hg.addColorStop(0.55, rgba(colA, 0.16));
      hg.addColorStop(1.0, rgba(colA, 0.0));

      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(cx + ox, cy + oy, baseR * (2.0 + t * 0.9), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.filter = "none";
    ctx.globalAlpha = 1.0;

    // vision ring
    if (visionOn) {
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.65;
      ctx.filter = `blur(${8 + baseR * 0.40}px)`;
      ctx.strokeStyle = dyeGradient(ctx, cx - baseR * 2, cy, cx + baseR * 2, cy, emoA, emoB, 0.40, 0.40);
      ctx.lineWidth = Math.max(2.5, baseR * 0.25);
      ctx.beginPath();
      ctx.arc(cx, cy, baseR * 1.85, 0, Math.PI * 2);
      ctx.stroke();
      ctx.filter = "none";
      ctx.globalAlpha = 1.0;
    }

    ctx.globalCompositeOperation = "source-over";
  };

  // Draw matches
  for (let mi = 0; mi < matches.length; mi++) {
    const matchId = matches[mi];
    const yBase = mainY + mi * rowH;

    // IMPORTANT FIX: compare as string
    const events = rows.filter(r => String(r.match).trim() === matchId);

    for (const e of events) {
      const minute = num(e.minute, 0);
      const x = mainX + (minute / maxMin) * mainW;

      const emotion = clamp(Math.round(num(e.emotion, 4)), 1, 5);
      const strength = (emotion - 1) / 4;

      const emo = CONFIG.EMO[String(emotion)];
      const emoA = emo.a, emoB = emo.b;

      const causeTint = CONFIG.CAUSE_TINT[e.cause] || CONFIG.CAUSE_TINT.Unknown;
      const angle = CONFIG.AREA_ANGLE[e.area] ?? CONFIG.AREA_ANGLE.Unknown;

      const smearK = CONFIG.smearByPhase(e.phase) * (0.55 + strength * 0.85);
      const visionOn = CONFIG.isVisionYes(e.vision);

      const baseR = CONFIG.baseR0 + emotion * CONFIG.baseRk;

      const seed = (minute * 9.7 + Number(matchId) * 3.3 + emotion * 2.1);
      const frac = seed - Math.floor(seed);
      const slot = Math.floor(frac * CONFIG.laneSlots);
      const y = yBase + rowH * (0.20 + (slot / (CONFIG.laneSlots - 1)) * 0.60);

      e._id = `${e.date}|${matchId}|${minute}|${e.area}|${e.phase}|${e.cause}|${e.vision}|${emotion}`;
      drawBlot(x, y, baseR, emoA, emoB, causeTint, angle, smearK, visionOn, e._id);

      hitPoints.push({ x, y, r: baseR * 1.8, evt: e });
    }
  }

  canvas._hitPoints = hitPoints;

  // ---- sidebar mini bars (same as before) ----
  const areaPairs = countBy(rows, "area").slice(0, 8);
  const causePairs = countBy(rows, "cause").slice(0, 8);

  const miniBars = (title, pairs, x, y, w, h, pickGrad) => {
    ctx.fillStyle = "rgba(0,0,0,0.80)";
    ctx.font = "12px system-ui, Arial";
    ctx.fillText(title, x, y + 12);

    const top = y + 20;
    const barH = Math.max(10, Math.floor((h - 24) / Math.max(1, pairs.length)));
    const maxV = Math.max(1, ...pairs.map(p => p[1]));

    for (let i = 0; i < pairs.length; i++) {
      const [label, v] = pairs[i];
      const bw = (v / maxV) * (w - 98);
      const yy = top + i * barH;

      ctx.fillStyle = "rgba(0,0,0,0.06)";
      ctx.fillRect(x + 92, yy + 2, w - 98, barH - 4);

      const g = pickGrad(label, yy);
      ctx.save();
      ctx.globalAlpha = 0.95;
      ctx.filter = "blur(0.6px)";
      ctx.fillStyle = g;
      ctx.fillRect(x + 92, yy + 2, bw, barH - 4);
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = 0.32;
      ctx.filter = "blur(2px)";
      ctx.fillStyle = g;
      ctx.fillRect(x + 92, yy + 2, bw, barH - 4);
      ctx.restore();

      ctx.filter = "none";
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.font = "11px system-ui, Arial";
      ctx.fillText(label, x, yy + barH - 3);

      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fillText(String(v), x + w - 26, yy + barH - 3);
    }
  };

  miniBars(
    "Area",
    areaPairs,
    sideX + 12,
    sideY + 10,
    sideW - 24,
    Math.floor(sideH * 0.46),
    (label, yy) => {
      const t = 1 + Math.floor(hash01("area|" + label) * 5);
      const p = CONFIG.EMO[String(t)];
      return dyeGradient(ctx, sideX, yy, sideX + sideW, yy, p.a, p.b, 0.65, 0.65);
    }
  );

  miniBars(
    "Cause",
    causePairs,
    sideX + 12,
    sideY + Math.floor(sideH * 0.50),
    sideW - 24,
    Math.floor(sideH * 0.46),
    (label, yy) => {
      const tint = CONFIG.CAUSE_TINT[label] || CONFIG.CAUSE_TINT.Unknown;
      return dyeGradient(ctx, sideX, yy, sideX + sideW, yy, tint, "#ffffff", 0.75, 0.10);
    }
  );

  // ---- bottom density ----
  ctx.fillStyle = "rgba(0,0,0,0.80)";
  ctx.font = "12px system-ui, Arial";
  ctx.fillText("Minute density", botX + 10, botY + 14);

  const bins = 40;
  const hist = new Array(bins).fill(0);
  for (const r of rows) {
    const m = clamp(num(r.minute, 0), 0, 39.999);
    const bi = Math.floor((m / 40) * bins);
    hist[bi] += 1;
  }
  const maxHist = Math.max(1, ...hist);

  for (let i = 0; i < bins; i++) {
    const x0 = botX + 10 + (i / bins) * (botW - 20);
    const bw = (botW - 20) / bins;
    const v = hist[i] / maxHist;
    const bh = v * (botH - 30);

    ctx.fillStyle = "rgba(0,0,0,0.06)";
    ctx.fillRect(x0, botY + botH - 10 - (botH - 30), bw - 1, botH - 30);

    const emoIdx = 1 + Math.floor((i / (bins - 1)) * 4.999);
    const p = CONFIG.EMO[String(emoIdx)];
    const g = dyeGradient(ctx, x0, botY, x0, botY + botH, p.a, p.b, 0.55, 0.55);

    ctx.save();
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = g;
    ctx.fillRect(x0, botY + botH - 10 - bh, bw - 1, bh);
    ctx.restore();

    ctx.save();
    ctx.globalAlpha = 0.26;
    ctx.filter = "blur(2px)";
    ctx.fillStyle = g;
    ctx.fillRect(x0, botY + botH - 10 - bh, bw - 1, bh);
    ctx.restore();

    ctx.filter = "none";
  }

  ctx.fillStyle = "rgba(0,0,0,0.45)";
  ctx.font = "11px system-ui, Arial";
  ctx.fillText("0", botX + 10, botY + botH - 4);
  ctx.fillText("20", botX + botW / 2 - 6, botY + botH - 4);
  ctx.fillText("40", botX + botW - 26, botY + botH - 4);

  // legend
  const lx = mainX + 10;
  const ly = mainY + mainH - 86;
  ctx.fillStyle = "rgba(255,255,255,0.78)";
  ctx.strokeStyle = "rgba(0,0,0,0.08)";
  ctx.fillRect(lx - 6, ly - 14, 250, 92);
  ctx.strokeRect(lx - 6, ly - 14, 250, 92);

  ctx.fillStyle = "rgba(0,0,0,0.80)";
  ctx.font = "12px system-ui, Arial";
  ctx.fillText("Emotion palettes (1–5)", lx, ly);

  let yy = ly + 10;
  for (let k = 1; k <= 5; k++) {
    const p = CONFIG.EMO[String(k)];
    const g = dyeGradient(ctx, lx, yy, lx + 78, yy, p.a, p.b, 0.85, 0.85);
    ctx.fillStyle = g;
    ctx.fillRect(lx, yy - 8, 78, 12);

    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.filter = "blur(2px)";
    ctx.fillStyle = g;
    ctx.fillRect(lx, yy - 8, 78, 12);
    ctx.restore();

    ctx.filter = "none";
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillText(String(k), lx + 86, yy + 2);
    yy += 14;
  }

  ctx.fillStyle = "rgba(0,0,0,0.70)";
  ctx.fillText("Hover dots to hear failures", lx + 120, ly + 24);
  ctx.fillText("Vision=Yes adds neon ring", lx + 120, ly + 40);
  ctx.fillText("Phase drag / Area direction", lx + 120, ly + 56);

  // debug
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fillText(`events: ${rows.length}`, mainX + 6, mainY + 14);
}

// ---------- init ----------
(async function init() {
  hideExtraCharts();

  const canvas = document.getElementById("tapestry");
  if (!canvas) return;
  bindHoverSound(canvas);

  let allRows = [];
  try {
    allRows = await loadCSV("data/deaths.csv");
  } catch (err) {
    console.error(err);
    // render error text onto canvas so it's not “silent”
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#000";
    ctx.font = "14px system-ui, Arial";
    ctx.fillText(String(err), 20, 40);
    return;
  }

  const sel = document.getElementById("phaseFilter");
  const getFiltered = () => (!sel || sel.value === "All") ? allRows : allRows.filter(r => r.phase === sel.value);

  const draw = () => {
    try {
      renderDashboard(canvas, getFiltered());
    } catch (err) {
      console.error(err);
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#000";
      ctx.font = "14px system-ui, Arial";
      ctx.fillText("Render error:", 20, 40);
      ctx.fillText(String(err), 20, 62);
    }
  };

  if (sel) sel.addEventListener("change", draw);
  window.addEventListener("resize", draw);

  draw();
})();